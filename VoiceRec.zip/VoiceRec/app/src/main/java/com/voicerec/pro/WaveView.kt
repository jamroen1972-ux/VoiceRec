package com.voicerec.pro

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class WaveView(c: Context, a: AttributeSet?) : View(c, a) {
    private val n = 36
    private val data = FloatArray(n)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val minH = 4f * resources.displayMetrics.density

    fun push(amp: Int) {
        System.arraycopy(data, 1, data, 0, n - 1)
        data[n - 1] = min(1f, sqrt(amp / 32767f) * 1.5f)
        invalidate()
    }

    fun clear() { data.fill(0f); invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        p.shader = LinearGradient(0f, 0f, w.toFloat(), 0f,
            intArrayOf(0xFF00E5FF.toInt(), 0xFFFFEA00.toInt(), 0xFFFF2E93.toInt()), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val bar = width.toFloat() / n
        p.strokeWidth = bar * 0.55f
        val mid = height / 2f
        for (i in 0 until n) {
            val hh = max(minH, data[i] * height)
            val cx = (i + 0.5f) * bar
            canvas.drawLine(cx, mid - hh / 2, cx, mid + hh / 2, p)
        }
    }
}

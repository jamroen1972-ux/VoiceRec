package com.voicerec.pro

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.media.PlaybackParams
import android.widget.SeekBar
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var tvTimer: TextView
    private lateinit var tvState: TextView
    private lateinit var btnRec: AnimalView
    private lateinit var ring: View
    private lateinit var btnPause: TextView
    private lateinit var swFloat: SwitchCompat
    private lateinit var wave: WaveView
    private lateinit var list: RecyclerView
    private lateinit var tvEmpty: TextView

    private val prefs by lazy { getSharedPreferences("vr", MODE_PRIVATE) }
    private val items = mutableListOf<File>()
    private val durCache = HashMap<String, String>()
    private var player: MediaPlayer? = null
    private var playingPath: String? = null
    private var wasRec = false
    private var lastKey = -1
    private var pending: (() -> Unit)? = null
    private var pulse: ObjectAnimator? = null
    private val listener: () -> Unit = { updateUi() }
    private val tlistener: () -> Unit = { adapter.notifyDataSetChanged() }
    private val adapter = RecAdapter()

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (micOk()) pending?.invoke()
        else { toast("ต้องอนุญาตไมโครโฟนก่อนครับ"); swFloat.isChecked = false }
        pending = null
    }

    private fun micOk() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun ensurePerms(ok: () -> Unit) {
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) ok() else { pending = ok; permLauncher.launch(missing.toTypedArray()) }
    }

    private fun circle(a: Int, b: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply { shape = GradientDrawable.OVAL }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvTimer = findViewById(R.id.tvTimer); tvState = findViewById(R.id.tvState)
        btnRec = findViewById(R.id.btnRec); ring = findViewById(R.id.ring)
        btnPause = findViewById(R.id.btnPause); swFloat = findViewById(R.id.swFloat)
        findViewById<TextView>(R.id.btnSettings).setOnClickListener { showSettings() }
        wave = findViewById(R.id.wave); list = findViewById(R.id.list); tvEmpty = findViewById(R.id.tvEmpty)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        speed = prefs.getFloat("speed", 1f)

        btnRec.setOnClickListener {
            if (RecState.recording) startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            else ensurePerms {
                ContextCompat.startForegroundService(this, Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START))
            }
        }
        btnPause.setOnClickListener {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_PAUSE))
        }
        swFloat.setOnClickListener {
            if (swFloat.isChecked) {
                ensurePerms {
                    if (!Settings.canDrawOverlays(this)) {
                        swFloat.isChecked = false
                        prefs.edit().putBoolean("float", true).apply()
                        AlertDialog.Builder(this).setTitle("ขออนุญาตปุ่มลอย")
                            .setMessage("เปิดสิทธิ์ \"แสดงทับแอปอื่น\" ให้ VoiceRec แล้วกลับมาที่แอปนี้")
                            .setPositiveButton("ไปตั้งค่า") { _, _ ->
                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                            }.setNegativeButton("ยกเลิก") { _, _ -> prefs.edit().putBoolean("float", false).apply() }.show()
                    } else { prefs.edit().putBoolean("float", true).apply(); startFloat() }
                }
            } else {
                prefs.edit().putBoolean("float", false).apply()
                stopService(Intent(this, FloatingService::class.java))
            }
        }
    }

    private fun startFloat() {
        if (!FloatingService.running)
            ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
    }

    override fun onStart() {
        super.onStart()
        RecState.listeners.add(listener)
        Transcriber.listeners.add(tlistener)
        lastKey = -1
        updateUi()
        reload()
    }

    override fun onResume() {
        super.onResume()
        val want = prefs.getBoolean("float", false) && Settings.canDrawOverlays(this) && micOk()
        swFloat.isChecked = want
        if (want) startFloat()
    }

    override fun onStop() {
        RecState.listeners.remove(listener)
        Transcriber.listeners.remove(tlistener)
        super.onStop()
    }

    override fun onDestroy() { stopPlay(); super.onDestroy() }

    private fun updateUi() {
        val rec = RecState.recording
        tvTimer.text = RecState.fmt(RecState.elapsed())
        if (rec && !RecState.paused) wave.push(RecState.amp) else if (!rec) wave.clear()
        val key = if (!rec) 0 else if (RecState.paused) 2 else 1
        if (key != lastKey) {
            lastKey = key
            when (key) {
                0 -> { tvState.text = "แตะสัตว์เพื่อเริ่มบันทึก"; btnPause.visibility = View.INVISIBLE }
                1 -> { tvState.text = "กำลังบันทึก... (ออกจากแอปได้เลย)"; btnPause.visibility = View.VISIBLE; btnPause.text = "⏸ พัก" }
                else -> { tvState.text = "หยุดชั่วคราว"; btnPause.visibility = View.VISIBLE; btnPause.text = "▶ ต่อ" }
            }
        }
        btnRec.animal = AnimalView.current(this)
        if (wasRec && !rec) reload()
        wasRec = rec
    }

    private fun reload() {
        items.clear()
        RecorderService.dir(this).listFiles { f -> f.extension == "m4a" }
            ?.sortedByDescending { it.lastModified() }?.let { items.addAll(it) }
        adapter.notifyDataSetChanged()
        tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private var speed = 1f
    private var dragging = false
    private var activeSeek: SeekBar? = null
    private var activePos: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val seekTick = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (!dragging) {
                try {
                    activeSeek?.progress = p.currentPosition
                    activePos?.text = RecState.fmt(p.currentPosition.toLong()) + " / " + RecState.fmt(p.duration.toLong())
                } catch (_: Exception) {}
            }
            ui.postDelayed(this, 200)
        }
    }

    private fun stopPlay() {
        ui.removeCallbacks(seekTick)
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null; playingPath = null
        activeSeek = null; activePos = null
        adapter.notifyDataSetChanged()
    }

    private fun applySpeed() {
        val p = player ?: return
        try {
            val was = p.isPlaying
            p.playbackParams = PlaybackParams().setSpeed(speed)
            if (!was && p.isPlaying) p.pause()
        } catch (_: Exception) {}
    }

    private fun togglePlay(f: File) {
        if (playingPath == f.path) {
            val p = player ?: return
            if (p.isPlaying) p.pause() else { p.start(); applySpeed(); ui.removeCallbacks(seekTick); ui.post(seekTick) }
            adapter.notifyDataSetChanged()
            return
        }
        stopPlay()
        try {
            player = MediaPlayer().apply {
                setDataSource(f.path); prepare(); start()
                setOnCompletionListener { mp -> mp.seekTo(0); adapter.notifyDataSetChanged() }
            }
            playingPath = f.path
            applySpeed()
            adapter.notifyDataSetChanged()
            ui.removeCallbacks(seekTick); ui.post(seekTick)
        } catch (e: Exception) { toast("เล่นไฟล์ไม่ได้"); stopPlay() }
    }

    private fun duration(f: File): String = durCache.getOrPut(f.path) {
        try {
            val m = MediaMetadataRetriever(); m.setDataSource(f.path)
            val ms = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            m.release(); RecState.fmt(ms)
        } catch (e: Exception) { "--:--" }
    }

    private fun showSettings() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val rg = RadioGroup(this)
        val rbG = RadioButton(this).apply { text = "Groq (whisper-large-v3)"; id = View.generateViewId() }
        val rbO = RadioButton(this).apply { text = "OpenAI (whisper-1)"; id = View.generateViewId() }
        rg.addView(rbG); rg.addView(rbO)
        if (Transcriber.provider(this) == "openai") rbO.isChecked = true else rbG.isChecked = true
        val et = EditText(this).apply { hint = "API key"; setSingleLine(); setText(Transcriber.key(this@MainActivity)) }
        val cb = CheckBox(this).apply { text = "ถอดข้อความอัตโนมัติหลังอัดเสร็จ"; isChecked = Transcriber.auto(this@MainActivity) }
        val tip = TextView(this).apply {
            textSize = 12f
            text = "ต้องต่อเน็ต และไฟล์เสียงจะถูกส่งไปประมวลผลที่เซิร์ฟเวอร์ของผู้ให้บริการ\nสมัคร API key: console.groq.com หรือ platform.openai.com"
        }
        val labA = TextView(this).apply { text = "เลือกสัตว์ประจำปุ่ม"; textSize = 13f }
        val rgA = RadioGroup(this)
        val names = arrayOf("🦉 นกฮูก", "🐰 กระต่าย", "🐱 แมว")
        val rbs = names.mapIndexed { i, n ->
            RadioButton(this).apply { text = n; id = View.generateViewId(); isChecked = (i == AnimalView.current(this@MainActivity)) }
        }
        rbs.forEach { rgA.addView(it) }
        val labT = TextView(this).apply { text = "ผู้ให้บริการถอดข้อความ"; textSize = 13f; setPadding(0, pad / 2, 0, 0) }
        box.addView(labA); box.addView(rgA); box.addView(labT)
        box.addView(rg); box.addView(et); box.addView(cb); box.addView(tip)
        AlertDialog.Builder(this).setTitle("ตั้งค่าถอดข้อความ").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("บันทึก") { _, _ ->
                Transcriber.save(this, if (rbO.isChecked) "openai" else "groq", et.text.toString().trim(), cb.isChecked)
                val sel = rbs.indexOfFirst { it.isChecked }.coerceAtLeast(0)
                AnimalView.save(this, sel); btnRec.animal = sel; RecState.fire()
                toast("บันทึกแล้ว")
            }.setNegativeButton("ยกเลิก", null).show()
    }

    private fun onTranscriptClick(f: File) {
        when {
            Transcriber.busy.contains(f.path) -> toast("กำลังถอดข้อความอยู่...")
            Transcriber.txtFile(f).exists() -> showTranscript(f)
            Transcriber.key(this).isEmpty() -> { toast("ใส่ API key ก่อนครับ"); showSettings() }
            else -> startTranscribe(f)
        }
    }

    private fun startTranscribe(f: File) {
        toast("เริ่มถอดข้อความ...")
        val app = applicationContext
        Thread {
            val r = Transcriber.run(app, f)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                r.onSuccess { showTranscript(f) }
                r.onFailure { Toast.makeText(this, "ถอดไม่สำเร็จ: ${it.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun showTranscript(f: File) {
        val txt = Transcriber.txtFile(f).readText()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply { text = txt; textSize = 16f; setTextIsSelectable(true); setPadding(pad, pad / 2, pad, pad / 2) }
        val sv = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this).setTitle(f.nameWithoutExtension).setView(sv)
            .setPositiveButton("คัดลอก") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("transcript", txt))
                toast("คัดลอกแล้ว")
            }
            .setNeutralButton("แชร์") { _, _ ->
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt)
                }, "แชร์ข้อความ"))
            }
            .setNegativeButton("ถอดใหม่") { _, _ ->
                if (Transcriber.key(this).isEmpty()) showSettings() else startTranscribe(f)
            }.show()
    }

    private fun share(f: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "audio/mp4"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "แชร์ไฟล์เสียง"))
    }

    private fun rename(f: File) {
        val et = EditText(this).apply { setText(f.nameWithoutExtension); setSingleLine() }
        AlertDialog.Builder(this).setTitle("เปลี่ยนชื่อ").setView(et)
            .setPositiveButton("ตกลง") { _, _ ->
                val n = et.text.toString().trim().replace(Regex("""[\\/:*?"<>|]"""), "_")
                if (n.isNotEmpty()) {
                    val nf = File(f.parentFile, "$n.m4a")
                    if (nf.exists()) toast("มีชื่อนี้อยู่แล้ว")
                    else { if (playingPath == f.path) stopPlay(); Transcriber.txtFile(f).let { t -> if (t.exists()) t.renameTo(Transcriber.txtFile(nf)) }; f.renameTo(nf); durCache.remove(f.path); reload() }
                }
            }.setNegativeButton("ยกเลิก", null).show()
    }

    private fun delete(f: File) {
        AlertDialog.Builder(this).setTitle("ลบไฟล์นี้?").setMessage(f.nameWithoutExtension)
            .setPositiveButton("ลบ") { _, _ ->
                if (playingPath == f.path) stopPlay()
                f.delete(); Transcriber.txtFile(f).delete(); durCache.remove(f.path); reload()
            }.setNegativeButton("ยกเลิก", null).show()
    }

    inner class RecAdapter : RecyclerView.Adapter<RecAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val play: TextView = v.findViewById(R.id.play)
            val name: TextView = v.findViewById(R.id.tvName)
            val meta: TextView = v.findViewById(R.id.tvMeta)
            val share: TextView = v.findViewById(R.id.share)
            val tr: TextView = v.findViewById(R.id.transcript)
            val box: View = v.findViewById(R.id.playerBox)
            val seek: SeekBar = v.findViewById(R.id.seek)
            val pos: TextView = v.findViewById(R.id.tvPos)
            val spd1: TextView = v.findViewById(R.id.spd1)
            val spd2: TextView = v.findViewById(R.id.spd2)
            val spd3: TextView = v.findViewById(R.id.spd3)
            val rename: TextView = v.findViewById(R.id.rename)
            val del: TextView = v.findViewById(R.id.delete)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_rec, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val f = items[i]
            h.name.text = f.nameWithoutExtension
            val kb = f.length() / 1024
            val size = if (kb >= 1024) String.format("%.1f MB", kb / 1024f) else "$kb KB"
            val date = SimpleDateFormat("d MMM HH:mm", Locale("th", "TH")).format(Date(f.lastModified()))
            h.meta.text = "${duration(f)} • $size • $date"
            val isCur = playingPath == f.path
            h.play.text = if (isCur && player?.isPlaying == true) "⏸" else "▶"
            h.box.visibility = if (isCur) View.VISIBLE else View.GONE
            if (isCur) {
                val p = player
                val dur = try { p?.duration ?: 0 } catch (_: Exception) { 0 }
                h.seek.max = dur
                h.seek.progress = try { p?.currentPosition ?: 0 } catch (_: Exception) { 0 }
                h.pos.text = RecState.fmt(h.seek.progress.toLong()) + " / " + RecState.fmt(dur.toLong())
                activeSeek = h.seek; activePos = h.pos
                h.seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                        if (fromUser) h.pos.text = RecState.fmt(v.toLong()) + " / " + RecState.fmt(s.max.toLong())
                    }
                    override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
                    override fun onStopTrackingTouch(s: SeekBar) {
                        dragging = false
                        try { player?.seekTo(s.progress) } catch (_: Exception) {}
                    }
                })
                val chips = arrayOf(h.spd1 to 1f, h.spd2 to 2f, h.spd3 to 3f)
                for ((tv, sp) in chips) {
                    val on = speed == sp
                    tv.setBackgroundResource(if (on) R.drawable.chip_on else R.drawable.pill)
                    tv.setTextColor(if (on) 0xFF3A0CA3.toInt() else android.graphics.Color.WHITE)
                    tv.setOnClickListener {
                        speed = sp; prefs.edit().putFloat("speed", sp).apply()
                        applySpeed(); adapter.notifyDataSetChanged()
                    }
                }
            } else if (activeSeek === h.seek) { activeSeek = null; activePos = null }
            h.play.setOnClickListener { togglePlay(f) }
            h.tr.text = when {
                Transcriber.busy.contains(f.path) -> "⏳"
                Transcriber.txtFile(f).exists() -> "📝"
                else -> "🔤"
            }
            h.tr.setOnClickListener { onTranscriptClick(f) }
            h.share.setOnClickListener { share(f) }
            h.rename.setOnClickListener { rename(f) }
            h.del.setOnClickListener { delete(f) }
        }
    }
}

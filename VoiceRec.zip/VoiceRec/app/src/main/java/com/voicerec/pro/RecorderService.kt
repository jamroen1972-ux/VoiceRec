package com.voicerec.pro

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.*
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : Service() {
    companion object {
        const val ACTION_START = "com.voicerec.pro.START"
        const val ACTION_STOP = "com.voicerec.pro.STOP"
        const val ACTION_PAUSE = "com.voicerec.pro.PAUSE"
        const val ACTION_TOGGLE = "com.voicerec.pro.TOGGLE"
        const val CH = "rec_channel"

        fun dir(ctx: Context): File {
            val d = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Recordings")
            d.mkdirs()
            return d
        }
    }

    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var tick = 0
    private val h = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            val r = rec ?: return
            RecState.amp = if (RecState.paused) 0 else try { r.maxAmplitude } catch (e: Exception) { 0 }
            RecState.fire()
            if (++tick % 10 == 0) updateNotif()
            h.postDelayed(this, 100)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRec()
            ACTION_STOP -> stopRec()
            ACTION_PAUSE -> togglePause()
            ACTION_TOGGLE -> if (RecState.recording) stopRec() else startRec()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun startRec() {
        if (rec != null) return
        try {
            createChannel()
            ServiceCompat.startForeground(this, 1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                throw IllegalStateException("ยังไม่ได้อนุญาตไมโครโฟน")
            val f = File(dir(this), "REC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a")
            val r = newRecorder()
            rec = r
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioEncodingBitRate(64000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            file = f
            RecState.begin()
            tick = 0
            h.post(ticker)
        } catch (e: Exception) {
            Toast.makeText(this, "เริ่มบันทึกไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
            try { rec?.release() } catch (_: Exception) {}
            rec = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun togglePause() {
        val r = rec ?: return
        try {
            if (RecState.paused) { r.resume(); RecState.resume() } else { r.pause(); RecState.pause() }
            updateNotif()
        } catch (_: Exception) {}
    }

    private fun stopRec() {
        if (rec == null) {
            if (Transcriber.busy.isEmpty()) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            return
        }
        h.removeCallbacks(ticker)
        var ok = true
        try { rec?.stop() } catch (_: Exception) { ok = false; file?.delete() }
        try { rec?.release() } catch (_: Exception) {}
        rec = null
        RecState.end()
        val f = file
        if (ok && f != null && f.exists() && Transcriber.auto(this) && Transcriber.key(this).isNotEmpty()) {
            autoTranscribe(f)
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun autoTranscribe(f: File) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1, NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("กำลังถอดข้อความ...").setContentText(f.nameWithoutExtension)
            .setOngoing(true).build())
        val app = applicationContext
        Thread {
            val r = Transcriber.run(app, f)
            h.post {
                val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                val msg = if (r.isSuccess) r.getOrNull().orEmpty().take(80) else r.exceptionOrNull()?.message.orEmpty().take(80)
                nm.notify(3, NotificationCompat.Builder(this, CH)
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle(if (r.isSuccess) "ถอดข้อความเสร็จแล้ว" else "ถอดข้อความไม่สำเร็จ")
                    .setContentText(msg).setContentIntent(open).setAutoCancel(true).build())
                if (rec == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            }
        }.start()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "การบันทึกเสียง", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun act(a: String, code: Int) = PendingIntent.getService(
        this, code, Intent(this, RecorderService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)

    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (RecState.paused) "⏸ หยุดชั่วคราว" else "🔴 กำลังบันทึกเสียง")
            .setContentText(RecState.fmt(RecState.elapsed()))
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
            .setColor(0xFFFF2E93.toInt())
            .addAction(0, if (RecState.paused) "ต่อ" else "พัก", act(ACTION_PAUSE, 1))
            .addAction(0, "หยุดและบันทึก", act(ACTION_STOP, 2))
            .build()
    }

    private fun updateNotif() {
        getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    override fun onDestroy() {
        h.removeCallbacks(ticker)
        try { rec?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}

package com.voicerec.pro

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.CopyOnWriteArraySet

object RecState {
    @Volatile var recording = false
    @Volatile var paused = false
    @Volatile var amp = 0
    private var accum = 0L
    private var lastStart = 0L
    val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val h = Handler(Looper.getMainLooper())

    fun elapsed(): Long =
        accum + if (recording && !paused) SystemClock.elapsedRealtime() - lastStart else 0L

    fun begin() { recording = true; paused = false; accum = 0; lastStart = SystemClock.elapsedRealtime(); fire() }
    fun pause() { accum += SystemClock.elapsedRealtime() - lastStart; paused = true; fire() }
    fun resume() { lastStart = SystemClock.elapsedRealtime(); paused = false; fire() }
    fun end() { recording = false; paused = false; accum = 0; amp = 0; fire() }
    fun fire() { h.post { listeners.forEach { it() } } }

    fun fmt(ms: Long): String {
        val s = ms / 1000
        val hh = s / 3600; val mm = (s % 3600) / 60; val ss = s % 60
        return if (hh > 0) String.format("%d:%02d:%02d", hh, mm, ss) else String.format("%02d:%02d", mm, ss)
    }
}

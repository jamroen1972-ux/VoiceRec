package com.voicerec.pro

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.min
import kotlin.math.sin

/** Round record button drawn as an animal face. animal: 0 owl, 1 rabbit, 2 cat. State is read from RecState. */
class AnimalView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    companion object {
        fun current(c: Context): Int = c.getSharedPreferences("vr", Context.MODE_PRIVATE).getInt("animal", 0)
        fun save(c: Context, v: Int) { c.getSharedPreferences("vr", Context.MODE_PRIVATE).edit().putInt("animal", v).apply() }
        private fun grad(a: Int, b: Int) = LinearGradient(-50f, -50f, 50f, 50f, a, b, Shader.TileMode.CLAMP)
    }

    var animal = 0
        set(v) { if (field != v) { field = v; invalidate() } }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val rect = RectF()
    private val bg = arrayOf(
        grad(0xFFFF2E93.toInt(), 0xFFFF9100.toInt()),
        grad(0xFFFF1744.toInt(), 0xFFD500F9.toInt()),
        grad(0xFFFFEA00.toInt(), 0xFFFF9100.toInt()))
    private val listener: () -> Unit = { invalidate() }

    init { animal = current(c) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); RecState.listeners.add(listener) }
    override fun onDetachedFromWindow() { RecState.listeners.remove(listener); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val st = if (!RecState.recording) 0 else if (RecState.paused) 2 else 1
        val t = SystemClock.uptimeMillis()
        val s = min(width, height) / 100f
        canvas.save()
        canvas.translate(width / 2f, height / 2f)
        canvas.scale(s, s)

        fill.style = Paint.Style.FILL
        fill.shader = bg[st]
        canvas.drawCircle(0f, 0f, 48f, fill)
        fill.shader = null
        line.color = Color.WHITE; line.strokeWidth = 3f
        canvas.drawCircle(0f, 0f, 48.5f, line)

        // eyes: asleep when idle, wide awake + blinking when recording, droopy when paused
        val e = when (st) { 0 -> 0f; 2 -> 0.45f; else -> if (t % 3200 < 160) 0.1f else 1f }
        // ears: drooped when idle, perked and wiggling when recording
        val ear = when (st) { 0 -> 16f; 2 -> 8f; else -> 1f + 4f * sin(t / 140.0).toFloat() }
        val look = if (st == 1) sin(t / 600.0).toFloat() * 2f else 0f
        when (animal) {
            1 -> rabbit(canvas, e, ear, look)
            2 -> cat(canvas, e, ear, look)
            else -> owl(canvas, e, ear, look)
        }
        canvas.restore()
        if (st == 1) postInvalidateOnAnimation()
    }

    private fun eye(cv: Canvas, cx: Float, cy: Float, rw: Float, rh: Float, e: Float,
                    sc: Int, pc: Int, pw: Float, ph: Float, dx: Float) {
        if (e < 0.15f) {
            line.color = 0xFF4E342E.toInt(); line.strokeWidth = 2.4f
            rect.set(cx - rw * 0.8f, cy - rh * 0.5f, cx + rw * 0.8f, cy + rh * 0.5f)
            cv.drawArc(rect, 10f, 160f, false, line)
            return
        }
        fill.color = sc; rect.set(cx - rw, cy - rh * e, cx + rw, cy + rh * e); cv.drawOval(rect, fill)
        fill.color = pc; rect.set(cx + dx - pw, cy - ph * e, cx + dx + pw, cy + ph * e); cv.drawOval(rect, fill)
    }

    private fun owl(cv: Canvas, e: Float, ear: Float, look: Float) {
        for (sd in intArrayOf(-1, 1)) {
            cv.save(); cv.rotate(sd * ear * 0.5f, sd * 18f, -14f)
            path.reset(); path.moveTo(sd * 10f, -20f); path.lineTo(sd * 20f, -36f); path.lineTo(sd * 30f, -14f); path.close()
            fill.color = 0xFF6D4C41.toInt(); cv.drawPath(path, fill); cv.restore()
        }
        fill.color = 0xFFFFE0B2.toInt(); rect.set(-31f, -24f, 31f, 34f); cv.drawOval(rect, fill)
        for (sd in intArrayOf(-1, 1)) {
            fill.color = 0xFFFFB74D.toInt(); cv.drawCircle(sd * 13f, -2f, 13.5f, fill)
            eye(cv, sd * 13f, -2f, 10f, 10f, e, Color.WHITE, 0xFF212121.toInt(), 5f, 5.5f, look)
        }
        path.reset(); path.moveTo(-5f, 10f); path.lineTo(5f, 10f); path.lineTo(0f, 22f); path.close()
        fill.color = 0xFFFF6D00.toInt(); cv.drawPath(path, fill)
        line.color = 0xFFBCAAA4.toInt(); line.strokeWidth = 2f
        for (i in -1..1) {
            rect.set(i * 10f - 5f, 25f, i * 10f + 5f, 33f)
            cv.drawArc(rect, 0f, 180f, false, line)
        }
    }

    private fun rabbit(cv: Canvas, e: Float, ear: Float, look: Float) {
        for (sd in intArrayOf(-1, 1)) {
            cv.save(); cv.rotate(sd * ear, sd * 11f, -8f)
            fill.color = Color.WHITE; rect.set(sd * 11f - 8f, -46f, sd * 11f + 8f, -6f); cv.drawOval(rect, fill)
            fill.color = 0xFFFFB6D9.toInt(); rect.set(sd * 11f - 4f, -40f, sd * 11f + 4f, -12f); cv.drawOval(rect, fill)
            cv.restore()
        }
        fill.color = Color.WHITE; rect.set(-27f, -10f, 27f, 38f); cv.drawOval(rect, fill)
        fill.color = 0x66FF4081; cv.drawCircle(-17f, 18f, 6f, fill); cv.drawCircle(17f, 18f, 6f, fill)
        for (sd in intArrayOf(-1, 1)) {
            eye(cv, sd * 11f, 8f, 5f, 6f, e, 0xFF3E2723.toInt(), Color.WHITE, 1.6f, 1.8f, -1.5f + look * 0.3f)
        }
        path.reset(); path.moveTo(-3.5f, 17f); path.lineTo(3.5f, 17f); path.lineTo(0f, 22f); path.close()
        fill.color = 0xFFFF4081.toInt(); cv.drawPath(path, fill)
        line.color = 0xFF8D6E63.toInt(); line.strokeWidth = 1.8f
        rect.set(-5f, 22f, 0f, 28f); cv.drawArc(rect, 0f, 180f, false, line)
        rect.set(0f, 22f, 5f, 28f); cv.drawArc(rect, 0f, 180f, false, line)
        line.color = 0xFFB0BEC5.toInt(); line.strokeWidth = 1.6f
        for (sd in intArrayOf(-1, 1)) {
            cv.drawLine(sd * 20f, 18f, sd * 34f, 15f, line)
            cv.drawLine(sd * 20f, 22f, sd * 34f, 24f, line)
        }
    }

    private fun cat(cv: Canvas, e: Float, ear: Float, look: Float) {
        for (sd in intArrayOf(-1, 1)) {
            cv.save(); cv.rotate(sd * ear * 0.5f, sd * 20f, -14f)
            path.reset(); path.moveTo(sd * 30f, -4f); path.lineTo(sd * 26f, -36f); path.lineTo(sd * 8f, -18f); path.close()
            fill.color = 0xFFFFF3E0.toInt(); cv.drawPath(path, fill)
            path.reset(); path.moveTo(sd * 26f, -8f); path.lineTo(sd * 24f, -28f); path.lineTo(sd * 13f, -17f); path.close()
            fill.color = 0xFFFFB6D9.toInt(); cv.drawPath(path, fill)
            cv.restore()
        }
        fill.color = 0xFFFFF3E0.toInt(); rect.set(-32f, -20f, 32f, 34f); cv.drawOval(rect, fill)
        line.color = 0xFFFF8F00.toInt(); line.strokeWidth = 2.5f
        cv.drawLine(-6f, -17f, -5f, -10f, line); cv.drawLine(0f, -18f, 0f, -9f, line); cv.drawLine(6f, -17f, 5f, -10f, line)
        for (sd in intArrayOf(-1, 1)) {
            eye(cv, sd * 13f, 2f, 7f, 8f, e, 0xFF26C6DA.toInt(), 0xFF212121.toInt(), 2.2f, 7f, look * 0.6f)
        }
        path.reset(); path.moveTo(-3f, 12f); path.lineTo(3f, 12f); path.lineTo(0f, 16f); path.close()
        fill.color = 0xFFFF4081.toInt(); cv.drawPath(path, fill)
        line.color = 0xFF8D6E63.toInt(); line.strokeWidth = 1.8f
        rect.set(-6f, 15f, 0f, 22f); cv.drawArc(rect, 0f, 180f, false, line)
        rect.set(0f, 15f, 6f, 22f); cv.drawArc(rect, 0f, 180f, false, line)
        for (sd in intArrayOf(-1, 1)) {
            cv.drawLine(sd * 16f, 14f, sd * 34f, 11f, line)
            cv.drawLine(sd * 16f, 18f, sd * 34f, 20f, line)
        }
    }
}

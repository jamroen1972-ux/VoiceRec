package com.voicerec.pro

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet

object Transcriber {
    val busy: MutableSet<String> = ConcurrentHashMap.newKeySet()
    val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val h = Handler(Looper.getMainLooper())

    private fun prefs(c: Context) = c.getSharedPreferences("vr", Context.MODE_PRIVATE)
    fun provider(c: Context): String = prefs(c).getString("provider", "groq") ?: "groq"
    private fun kp(c: Context) = c.getSharedPreferences("vr_key", Context.MODE_PRIVATE)

    fun key(c: Context): String {
        val k = kp(c).getString("key", "")?.trim().orEmpty()
        if (k.isNotEmpty()) return k
        // migrate a key saved by older versions
        val old = prefs(c).getString("key", "")?.trim().orEmpty()
        if (old.isNotEmpty()) {
            kp(c).edit().putString("key", old).apply()
            prefs(c).edit().remove("key").apply()
        }
        return old
    }

    fun saveKey(c: Context, k: String) {
        val cur = key(c)
        val e = kp(c).edit()
        if (cur.isNotEmpty() && cur != k) e.putString("prev", cur)
        e.putString("key", k).apply()
    }

    fun hasPrev(c: Context): Boolean = kp(c).getString("prev", "").orEmpty().isNotEmpty()

    fun restorePrev(c: Context) {
        val prev = kp(c).getString("prev", "").orEmpty()
        if (prev.isEmpty()) return
        val cur = key(c)
        kp(c).edit().putString("key", prev).putString("prev", cur).apply()
    }

    fun clearKey(c: Context) {
        val cur = key(c)
        val e = kp(c).edit()
        if (cur.isNotEmpty()) e.putString("prev", cur)
        e.putString("key", "").apply()
    }
    fun auto(c: Context): Boolean = prefs(c).getBoolean("auto", false)
    fun save(c: Context, provider: String, auto: Boolean) {
        prefs(c).edit().putString("provider", provider).putBoolean("auto", auto).apply()
    }

    fun txtFile(f: File) = File(f.parentFile, f.nameWithoutExtension + ".txt")

    private fun fire() { h.post { listeners.forEach { it() } } }

    /** Blocking call: send the audio file to a Whisper-compatible API and save the text next to it. */
    fun run(ctx: Context, f: File): Result<String> {
        busy.add(f.path); fire()
        try {
            val key = key(ctx)
            if (key.isEmpty()) return Result.failure(Exception("ยังไม่ได้ใส่ API key"))
            if (f.length() > 25L * 1024 * 1024) return Result.failure(Exception("ไฟล์ใหญ่เกิน 25 MB"))
            val openai = provider(ctx) == "openai"
            val url = URL(if (openai) "https://api.openai.com/v1/audio/transcriptions"
                          else "https://api.groq.com/openai/v1/audio/transcriptions")
            val model = if (openai) "whisper-1" else "whisper-large-v3"
            val b = "----VR" + System.currentTimeMillis()
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 30000; c.readTimeout = 300000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.setChunkedStreamingMode(16384)
            DataOutputStream(c.outputStream).use { o ->
                fun field(n: String, v: String) {
                    o.writeBytes("--$b\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n")
                }
                field("model", model); field("language", "th")
                field("response_format", "json"); field("temperature", "0")
                o.writeBytes("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n")
                f.inputStream().use { it.copyTo(o) }
                o.writeBytes("\r\n--$b--\r\n")
            }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) return Result.failure(Exception("HTTP $code ${body.take(200)}"))
            val text = JSONObject(body).optString("text").trim()
            if (text.isEmpty()) return Result.failure(Exception("ไม่พบเสียงพูดในไฟล์"))
            txtFile(f).writeText(text)
            return Result.success(text)
        } catch (e: Exception) {
            return Result.failure(e)
        } finally {
            busy.remove(f.path); fire()
        }
    }
}

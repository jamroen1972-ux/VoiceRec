package com.voicerec.pro

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Two rope-like strands that twist in waves around the record button. Calm when idle, wild with the voice while recording. */
class RopeView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val p1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val p2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val path = Path()
    private var phase = 0f
    private var lvl = 0f
    private var last = 0L

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f; val cy = h / 2f
        p1.shader = SweepGradient(cx, cy,
            intArrayOf(0xFF00E5FF.toInt(), 0xFFFFEA00.toInt(), 0xFFFF2E93.toInt(), 0xFF00E5FF.toInt()), null)
        p2.shader = SweepGradient(cx, cy,
            intArrayOf(0xFFFF2E93.toInt(), 0xFFFFFFFF.toInt(), 0xFF00E5FF.toInt(), 0xFFFF2E93.toInt()), null)
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 16L else min(now - last, 50L)
        last = now
        val st = if (!RecState.recording) 0 else if (RecState.paused) 2 else 1
        val speed = when (st) { 0 -> 0.7f; 2 -> 0.5f; else -> 2.4f }
        phase += speed * dt / 1000f
        val target = when (st) {
            0 -> 0.25f
            2 -> 0.2f
            else -> 0.45f + min(1f, sqrt(RecState.amp / 32767f) * 1.6f) * 0.55f
        }
        lvl += (target - lvl) * 0.15f

        val d = resources.displayMetrics.density
        val cx = width / 2f; val cy = height / 2f
        val base = min(width, height) / 2f - 12f * d
        val amp = (3f + 6f * lvl) * d
        p1.strokeWidth = 4.5f * d; p2.strokeWidth = 4.5f * d
        strand(canvas, p1, cx, cy, base, amp, phase)
        strand(canvas, p2, cx, cy, base, amp, phase + Math.PI.toFloat())
        postInvalidateOnAnimation()
    }

    private fun strand(c: Canvas, p: Paint, cx: Float, cy: Float, base: Float, amp: Float, ph: Float) {
        path.reset()
        val n = 180
        val rot = phase * 0.35f
        for (i in 0..n) {
            val th = i.toFloat() / n * 2f * Math.PI.toFloat()
            val r = base + amp * sin(6f * th + ph)
            val x = cx + r * cos(th + rot)
            val y = cy + r * sin(th + rot)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, p)
    }
}

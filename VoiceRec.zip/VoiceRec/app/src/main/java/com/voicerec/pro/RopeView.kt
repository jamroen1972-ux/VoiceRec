package com.voicerec.pro

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Neon rope effect around the record button: two glowing strands braided in waves, colours flowing around,
 * comet lights orbiting, and ripples while recording. Calm when idle, reacts to the voice while recording.
 */
class RopeView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private fun strokePaint() = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val glow = strokePaint()
    private val core = strokePaint()
    private val hl = strokePaint().apply { color = Color.WHITE }
    private val ripple = strokePaint().apply { color = Color.WHITE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val path = Path()
    private val m = Matrix()
    private var s1: SweepGradient? = null
    private var s2: SweepGradient? = null
    private var phase = 0f
    private var hue = 0f
    private var lvl = 0f
    private var last = 0L
    private val TAU = (Math.PI * 2).toFloat()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f; val cy = h / 2f
        s1 = SweepGradient(cx, cy, intArrayOf(0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF2E93.toInt(), 0xFFFFEA00.toInt(), 0xFF00E5FF.toInt()), null)
        s2 = SweepGradient(cx, cy, intArrayOf(0xFFFFEA00.toInt(), 0xFFFF2E93.toInt(), 0xFF00E5FF.toInt(), 0xFF76FF03.toInt(), 0xFFFFEA00.toInt()), null)
    }

    override fun onDraw(canvas: Canvas) {
        val sh1 = s1 ?: return
        val sh2 = s2 ?: return
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 16L else min(now - last, 50L)
        last = now
        val st = if (!RecState.recording) 0 else if (RecState.paused) 2 else 1
        phase += when (st) { 0 -> 0.7f; 2 -> 0.5f; else -> 2.4f } * dt / 1000f
        hue += when (st) { 0 -> 45f; 2 -> 30f; else -> 150f } * dt / 1000f
        val target = when (st) {
            0 -> 0.25f
            2 -> 0.2f
            else -> 0.45f + min(1f, sqrt(RecState.amp / 32767f) * 1.6f) * 0.55f
        }
        lvl += (target - lvl) * 0.15f

        val d = resources.displayMetrics.density
        val cx = width / 2f; val cy = height / 2f
        val base = min(width, height) / 2f - 16f * d
        val amp = (3f + 6f * lvl) * d
        val rot = phase * 0.35f

        m.setRotate(hue, cx, cy); sh1.setLocalMatrix(m)
        m.setRotate(-hue * 0.8f, cx, cy); sh2.setLocalMatrix(m)

        // ripples while recording
        if (st == 1) {
            for (k in 0..1) {
                val pr = ((now + k * 700L) % 1400L) / 1400f
                ripple.strokeWidth = 2f * d
                ripple.alpha = (110 * (1f - pr)).toInt()
                canvas.drawCircle(cx, cy, 50f * d + pr * 22f * d, ripple)
            }
        }

        for (n in 0..1) {
            val sh = if (n == 0) sh1 else sh2
            val ph = phase + if (n == 0) 0f else Math.PI.toFloat()
            path.reset()
            val steps = 200
            for (i in 0..steps) {
                val th = i.toFloat() / steps * TAU
                val r = base + amp * sin(6f * th + ph)
                val x = cx + r * cos(th + rot); val y = cy + r * sin(th + rot)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            glow.shader = sh; core.shader = sh
            glow.strokeWidth = 13f * d; glow.alpha = 40; canvas.drawPath(path, glow)
            glow.strokeWidth = 8f * d; glow.alpha = 85; canvas.drawPath(path, glow)
            core.strokeWidth = 4f * d; core.alpha = 255; canvas.drawPath(path, core)
            hl.strokeWidth = 1.2f * d; hl.alpha = 150; canvas.drawPath(path, hl)
        }

        // comet lights orbiting along strand 1
        for (k in 0..2) {
            val head = rot * 3f + k * TAU / 3f
            for (j in 0..6) {
                val th = head - j * 0.075f
                val r = base + amp * sin(6f * th + phase)
                val x = cx + r * cos(th + rot); val y = cy + r * sin(th + rot)
                if (j == 0) {
                    dot.alpha = 70; canvas.drawCircle(x, y, 9f * d, dot)
                }
                dot.alpha = (255 * (1f - j / 7f)).toInt()
                canvas.drawCircle(x, y, (3.8f - j * 0.4f) * d, dot)
            }
        }
        postInvalidateOnAnimation()
    }
}

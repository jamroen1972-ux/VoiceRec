package com.voicerec.pro

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

class FloatingService : Service() {
    companion object { @Volatile var running = false }

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private lateinit var btn: TextView
    private lateinit var timer: TextView
    private var pulse: ObjectAnimator? = null
    private var lastKey = -1
    private val h = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { refresh() }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        running = true
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("float_channel", "ปุ่มลอย", NotificationManager.IMPORTANCE_MIN))
        }
        val n = NotificationCompat.Builder(this, "float_channel")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ปุ่มลอย VoiceRec ทำงานอยู่")
            .setContentText("แตะปุ่มลอยเพื่อเริ่ม/หยุดบันทึก")
            .setOngoing(true).build()
        ServiceCompat.startForeground(this, 2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        btn = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 26f; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(60), dp(60))
        }
        timer = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); visibility = View.GONE
            setPadding(dp(8), dp(2), dp(8), dp(2))
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xCC000000.toInt()) }
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(btn); addView(timer)
        }
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(220) }
        wm.addView(root, params)
        setupTouch()
        RecState.listeners.add(listener)
        refresh()
    }

    private fun setupTouch() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0f; var sy = 0f; var ix = 0; var iy = 0
        var moved = false; var longPressed = false
        val longRun = Runnable {
            longPressed = true
            if (RecState.recording) startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_PAUSE))
        }
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ix = params.x; iy = params.y
                    moved = false; longPressed = false
                    h.postDelayed(longRun, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) { moved = true; h.removeCallbacks(longRun) }
                    if (moved) { params.x = ix + dx.toInt(); params.y = iy + dy.toInt(); wm.updateViewLayout(root, params) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(longRun)
                    if (e.action == MotionEvent.ACTION_UP && !moved && !longPressed) {
                        ContextCompat.startForegroundService(this,
                            Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_TOGGLE))
                    }
                }
            }
            true
        }
    }

    private fun setColors(a: Int, b: Int) {
        btn.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply {
            shape = GradientDrawable.OVAL; setStroke(dp(3), Color.WHITE)
        }
    }

    private fun refresh() {
        if (root == null) return
        val key = if (!RecState.recording) 0 else if (RecState.paused) 2 else 1
        if (RecState.recording) { timer.visibility = View.VISIBLE; timer.text = RecState.fmt(RecState.elapsed()) }
        else timer.visibility = View.GONE
        if (key == lastKey) return
        lastKey = key
        pulse?.cancel(); btn.scaleX = 1f; btn.scaleY = 1f
        when (key) {
            0 -> { btn.text = "🎙"; setColors(0xFFFF2E93.toInt(), 0xFFFF9100.toInt()) }
            1 -> {
                btn.text = "⏹"; setColors(0xFFFF1744.toInt(), 0xFFD500F9.toInt())
                pulse = ObjectAnimator.ofPropertyValuesHolder(btn,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.15f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.15f)).apply {
                    duration = 600; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start()
                }
            }
            else -> { btn.text = "▶"; setColors(0xFFFFEA00.toInt(), 0xFFFF9100.toInt()) }
        }
    }

    override fun onDestroy() {
        running = false
        RecState.listeners.remove(listener)
        pulse?.cancel()
        try { root?.let { wm.removeView(it) } } catch (_: Exception) {}
        root = null
        super.onDestroy()
    }
}

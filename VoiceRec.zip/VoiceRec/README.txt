VoiceRec - Android Studio project

1) เปิด Android Studio (Koala หรือใหม่กว่า) > File > Open > เลือกโฟลเดอร์ VoiceRec
2) รอ Gradle Sync เสร็จ
3) ต่อมือถือ (เปิด USB debugging) แล้วกด Run  หรือ
   Build > Build APK(s) เพื่อได้ไฟล์ APK ที่ app/build/outputs/apk/debug/
4) เปิดแอป > แตะสวิตช์ "ปุ่มลอย" > อนุญาตไมค์/แจ้งเตือน/แสดงทับแอปอื่น

ปุ่มลอย: แตะ = เริ่ม/หยุด, กดค้าง = พัก/ต่อ, ลากเพื่อย้ายตำแหน่ง
ไฟล์เสียงเก็บที่ Android/data/com.voicerec.pro/files/Music/Recordings (.m4a)

สร้าง APK ผ่าน GitHub: อัปโหลดไฟล์ทั้งหมด (รวมโฟลเดอร์ .github) ขึ้น repo
แล้วเปิดแท็บ Actions > Build APK > รอเสร็จ > ดาวน์โหลด VoiceRec-apk

ถอดเสียงเป็นข้อความ: แตะ ⚙️ ในแอป > เลือก Groq หรือ OpenAI > ใส่ API key
แล้วแตะ 🔤 ที่ไฟล์เสียงเพื่อถอดข้อความ (ผลเก็บเป็น .txt ข้างไฟล์เสียง)
ติ๊ก "ถอดข้อความอัตโนมัติ" เพื่อถอดทันทีหลังอัดเสร็จ

สัตว์ประจำปุ่ม: แตะ ⚙️ > เลือก นกฮูก / กระต่าย / แมว (เปลี่ยนทั้งปุ่มในแอปและปุ่มลอย)
